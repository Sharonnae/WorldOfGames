from Live import load_game, welcome

print(welcome("Gil"))
selections = load_game()